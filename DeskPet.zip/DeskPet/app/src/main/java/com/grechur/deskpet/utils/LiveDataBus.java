package com.grechur.deskpet.utils;

import java.util.Map;

public final class LiveDataBus {
    private final Map<String,BusMutableLiveData<Object>> bus;

}
